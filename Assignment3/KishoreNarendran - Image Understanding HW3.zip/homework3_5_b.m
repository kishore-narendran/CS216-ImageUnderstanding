img = im2double(imread('segtest1.jpg'));
imshow(img);
[ x, y ] = ginput(2);
close;

H = size(img,1);
W = size(img,2);
N = size(img,1)*size(img,2);

lambda = 1;
segclass = zeros(N,1);
pairwise = sparse(N,N);

img_quantized = color_quantization_indexes(img,20);








