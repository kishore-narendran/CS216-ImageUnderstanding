1) First, try to use the pre-compiled binaries as is: 
   Test them out by running hw3_demo.m from MATLAB

2) If that doesn't work, run GCmex_compile.m from MATLAB and then run hw3_demo.m
